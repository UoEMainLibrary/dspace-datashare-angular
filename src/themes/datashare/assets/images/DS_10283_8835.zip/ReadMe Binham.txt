Collection Name: Windows on the Past: Laser Scanning (LIDAR) Survey of Binham Priory, Norfolk, UK

Project Name: Windows on the Past: Digital Analysis of Window Design in Later Medieval England (1200-1300)

Data Publisher: University of Edinburgh, Edinburgh School of Architecture and Landscape Architecture.

Project Description: The dataset consists of a group of point cloud models of the church at Binham Priory in Norfolk, UK. These were generated from a laser scanning (LIDAR) survey conducted on 1st July 2024. The survey was undertaken as part of the Windows on the Past: Digital Analysis of Window Design in Later Medieval England (1200-1300) project, funded by the Paul Mellon Centre. Its Principal Investigator was James Hillson during the time was a Lecturer in Architectural History at the University of Edinburgh (2023-24). 

The aim of the project was to use laser scanning data to analyse window design processes, focusing on the critical period of the introduction of bar tracery into medieval England (c. 1200-1300). This resulted in both RAW scanning data and processed point clouds for two key sites in East Anglia: Binham Priory (Norfolk, UK) and the South Transept at Ely Cathedral (Cambridgeshire, UK). The dataset provided here consists of the RAW scanning data and the processed point cloud data for Binham Priory, made publicly available in .e57 format for any non-commercial purpose. Further details regarding the dataset and the surveying process can be found in the accompanying .xls spreadsheet.

The dataset for the South Transept at Ely Cathedral can also be found on Edinburgh DataShare.

Project Contents:

Group 1 - Finding Aids and Metadata [2 files, .xls and .jpg format]
� WotP_Binham_Priory_point_cloud_metadata.xls  -  Spreadsheet of metadata for scanning process and point clouds.
� WotP_Binham_Priory_Site_Plan_Bay_and_Window_Key.jpg  -  Plan identifying bay positions for point clouds.

Group 2 - Interior Point Cloud Models [8 files, .e57 format]
� WotP_Binham_Priory_point_cloud_interior_C7.e57  -  Processed point cloud model for interior of Binham Priory, Bay C7.
� WotP_Binham_Priory_point_cloud_interior_C8.e57  -  Processed point cloud model for interior of Binham Priory, Bay C8.
� WotP_Binham_Priory_point_cloud_interior_C9.e57  -  Processed point cloud model for interior of Binham Priory, Bay C9.
� WotP_Binham_Priory_point_cloud_interior_C10.e57  -  Processed point cloud model for interior of Binham Priory, Bay C10.
� WotP_Binham_Priory_point_cloud_interior_C11.e57  -  Processed point cloud model for interior of Binham Priory, Bay C11.
� WotP_Binham_Priory_point_cloud_interior_C12.e57  -  Processed point cloud model for interior of Binham Priory, Bay C12.
� WotP_Binham_Priory_point_cloud_interior_C13.e57  -  Processed point cloud model for interior of Binham Priory, Bay C13.
� WotP_Binham_Priory_point_cloud_interior_N13.e57  -  Processed point cloud model for interior of Binham Priory, Bay N13.

Group 3 - Exterior Point Cloud Models [1 file, .e57 format]
� WotP_Binham_Priory_point_cloud_exterior_C13.e57  -  Processed point cloud model for exterior of Binham Priory, Bay C13.

Group 4 - Interior RAW Point Clouds [12 files, .e57 format]
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-8.e57  -  RAW point cloud data for interior of Binham Priory (1 of 12 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-9.e57  -  RAW point cloud data for interior of Binham Priory (2 of 12 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-10.e57  -  RAW point cloud data for interior of Binham Priory (3 of 12 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-11.e57  -  RAW point cloud data for interior of Binham Priory (4 of 12 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-12.e57  -  RAW point cloud data for interior of Binham Priory (5 of 12 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-13.e57  -  RAW point cloud data for interior of Binham Priory (6 of 12 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-14.e57  -  RAW point cloud data for interior of Binham Priory (7 of 12 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-15.e57  -  RAW point cloud data for interior of Binham Priory (8 of 12 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-17.e57  -  RAW point cloud data for interior of Binham Priory (9 of 12 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-18.e57  -  RAW point cloud data for interior of Binham Priory (10 of 12 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-19.e57  -  RAW point cloud data for interior of Binham Priory (11 of 12 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-20.e57  -  RAW point cloud data for interior of Binham Priory (12 of 12 setups).

Group 5 - Exterior RAW Point Clouds [6 files, .e57 format]
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-1.e57  -  RAW point cloud data for exterior of Binham Priory (1 of 6 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-2.e57  -  RAW point cloud data for exterior of Binham Priory (2 of 6 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-3.e57  -  RAW point cloud data for exterior of Binham Priory (3 of 6 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-4.e57  -  RAW point cloud data for exterior of Binham Priory (4 of 6 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-5.e57  -  RAW point cloud data for exterior of Binham Priory (5 of 6 setups).
� WotP_Binham_Priory_RAW_point_cloud_WR3-18-6.e57  -  RAW point cloud data for exterior of Binham Priory (6 of 6 setups).
